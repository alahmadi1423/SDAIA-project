"""تشغيل: python cli.py            (محادثة)
          python cli.py -q "سؤالك"  (سؤال واحد)"""
import argparse

from marja.agent import ask, make_client
from marja.retrieval import Index, load_chunks


def show(ans):
    print("\n" + ans.text)
    for c in ans.citations:
        print(f"  [{c.id}] {c.source} - {c.heading}")
    if ans.quarantined:
        print(f"  (تم عزل مقاطع مشبوهة: {', '.join(ans.quarantined)})")
    print()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--docs", default="docs")
    ap.add_argument("-q", "--question")
    args = ap.parse_args()
    index = Index(load_chunks(args.docs))
    client = make_client()
    if args.question:
        return show(ask(args.question, index, client))
    while (q := input("سؤالك (او exit): ").strip()) and q != "exit":
        show(ask(q, index, client))


if __name__ == "__main__":
    main()
